# Frame Profiler

## 功能作用

Frame Profiler 是一个 Android 帧性能分析工具，核心功能包括：

- **在线帧数据采集**：通过两种方式实时采集帧数据：
  - **FrameMetrics Agent**：通过设备上的 Agent 回调获取 `FrameMetrics` API 数据，提供完整的帧阶段分解
  - **gfxinfo 轮询**：通过 ADB 执行 `dumpsys gfxinfo <package> framestats` 获取帧统计数据
- **离线导入**：支持导入 `gfxinfo framestats` 导出的文本文件
- **Jank（卡顿）分析**：`FrameJankAnalyzer` 分析每一帧的耗时，判断是否超过预期帧时长（如 16.67ms @ 60Hz），并按 Jank 类型分类
- **帧阶段分解**：支持将每帧分解为 8 个阶段：
  - Input、Animation、Layout/Measure、Draw、Sync、Command、Swap、GPU
- **帧详情展示**：可视化每一帧的耗时柱状图，标注 Jank 帧，支持选中单帧查看详情
- **布局反向关联**：选中单帧后可跳转到 Layout Inspector 查看对应时刻的布局（`FrameLayoutInspectionRequest`）
- **多种数据源**：支持 `JankStats`、`FrameMetrics`、`gfxinfo`、`Perfetto` 四种数据源

## 实现原理

### 采集流程

1. **设备选择 → 进程枚举**：通过 ADB 列出可调试进程
2. **打开采集会话**：
   - `FrameMetricsAgentCaptureSession`：通过 ADB 端口转发 + Socket 与设备上的 Agent 通信，Agent 在 App 进程内监听 `FrameMetrics` 回调
   - `GfxInfoPollingCaptureSession`：循环执行 `dumpsys gfxinfo <package> framestats`，解析输出中的帧数据行
3. **轮询**：以 `POLL_INTERVAL_MILLIS`（1 秒）间隔轮询新帧数据
4. **停止并分析**：停止采集后，将所有帧数据传给 `FrameJankAnalyzer` 进行分析

### 数据分析

- **Jank 判定**：`FrameJankAnalyzer` 对每帧计算 `resolvedDurationNs()`（实际耗时），与 `expectedDurationNs`（基于刷新率的预期时长）对比：
  - 超过预期：标记为 `DEADLINE_MISSED`
  - 超过预期 2x：标记为严重 Jank
- **平台 Jank 分类**：依赖数据源的能力（`FrameSourceCapabilities`），FrameMetrics 可提供 `platformJankTypes`（如 SLOW_INPUT、SLOW_DRAW 等）
- **帧阶段贡献**：`FrameStages` 记录各阶段耗时（单位纳秒），用于定位性能瓶颈在哪个阶段

### 数据结构

- **FrameSample**：单帧数据，包含 frameId、source、packageName、intendedVsync/actualVsync/present 时间戳、expectedDurationNs、stages（各阶段耗时）、platformJankTypes、droppedBeforeSample（丢失帧数）
- **FrameCaptureSession**：采集会话元数据，包含 id、source、startedAt、packageName
- **FrameSourceCapabilities**：数据源能力描述（是否支持实时采集、阶段分解、Jank 分类、预期帧截止时间、App 状态标签）

### 数据流

```
[Android Device] --FrameMetrics Agent/ADB gfxinfo--> [OnlineFrameCapture]
    --> [FrameSample[]] --> [FrameJankAnalyzer] --> [FrameAnalysisResult]
    --> [Compose UI: FrameProfilerScreen]
```

### Export

- **CSV**：帧分析结果 CSV 导出
- **JSON**：帧分析结果 JSON 导出
- **FrameStats 导入**：支持从 `dumpsys gfxinfo framestats` 输出文本导入
