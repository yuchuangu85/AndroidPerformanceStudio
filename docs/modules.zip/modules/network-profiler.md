# Network Profiler

## 功能作用

Network Profiler 是一个 Android 网络请求分析工具，核心功能包括：

- **在线网络采集**：通过设备上的 `NetworkProfilerAgent` 实时捕获 App 的 HTTP 网络请求
- **Agent 方式采集**：Agent 在 App 进程内通过 OkHttp EventListener 回调获取网络事件的精确时间戳（DNS、Connect、TLS、Request、Response 等各阶段耗时）
- **HAR 导入**：支持导入 HAR（HTTP Archive）格式文件进行离线分析
- **网络调用分析**：`NetworkAnalyzer` 分析 HTTP 调用的：
  - 请求方法（GET/POST 等）
  - URL（脱敏处理后）
  - 各阶段耗时分解（DNS 解析、TCP 连接、TLS 握手、请求发送、服务器等待、响应接收）
  - 状态码和结果（成功/失败/取消/不完整）
  - 请求/响应体积（字节）
  - 缓存状态（Hit/Miss/Conditional Hit）
- **会话管理**：通过 `SqliteNetworkStore` 持久化采集结果
- **多格式导出**：支持 JSON、HAR、CSV、Raw Bundle 多种导出格式

## 实现原理

### 采集流程

1. **Agent 部署**：`NetworkAgentCapture` 通过 ADB 与设备上的 Agent 建立连接
2. **事件捕获**：Agent 在 App 进程中通过 OkHttp EventListener 注册回调，捕获：
   - `callStart` / `callEnd`：请求开始和结束
   - `dnsStart` / `dnsEnd`：DNS 解析耗时
   - `connectStart` / `connectEnd`：TCP 连接耗时
   - `secureConnectStart` / `secureConnectEnd`：TLS 握手耗时
   - `requestHeadersStart` / `requestHeadersEnd`：请求头发送耗时
   - `requestBodyStart` / `requestBodyEnd`：请求体发送耗时
   - `responseHeadersStart` / `responseHeadersEnd`：响应头接收耗时
   - `responseBodyStart` / `responseBodyEnd`：响应体接收耗时
3. **轮询传输**：桌面端以 750ms 间隔轮询 Agent，拉取累积的网络事件
4. **事件组装**：`NetworkEventAssembler` 将原始事件组装成完整的 `HttpCall` 对象（含 `HttpExchange` 和 `NetworkPhase`）
5. **HAR 导入**：`HarParser` 解析 HAR JSON 文件，提取 entries 并转换为内部数据模型

### 数据分析

- **时序分析**：每条请求按阶段分解耗时，识别瓶颈阶段（DNS 慢 / TCP 慢 / TLS 慢 / 服务器慢）
- **成功率统计**：按状态码分类（2xx/3xx/4xx/5xx）
- **数据量统计**：请求/响应体积统计
- **并发分析**：同时进行的请求数

### 数据结构

- **HttpCall**：单次 HTTP 调用，包含 callId、method、redactedUrl、startedNs/endedNs、exchanges、outcome、source
- **HttpExchange**：单次 HTTP 交换，包含 statusCode、requestBytes/responseBytes、phases、failure
- **NetworkPhase**：单个网络阶段，包含 kind（DISPATCHER_QUEUE/PROXY_SELECT/DNS/CONNECT/TLS/REQUEST_HEADERS/REQUEST_BODY/SERVER_WAIT/RESPONSE_HEADERS/RESPONSE_BODY/CONNECTION_HELD/TOTAL）、startNs/endNs、confidence
- **NetworkCoverage**：覆盖率信息，包括 observedLibraries、instrumentationMode、supportedEventKinds、unsupportedStacks、droppedEvents、completeness

### 数据流

```
[Android Device] --ADB Socket--> [NetworkAgentCapture] --Poll--> [NetworkEventAssembler]
    --> [HttpCall[]] --> [NetworkAnalyzer] --> [Summary]
    --> [SqliteNetworkStore] (持久化)
    --> [Compose UI: NetworkProfilerScreen]

[HAR File] --> [HarParser] --> [HttpCall[]] --> [同上]
```

### 采集覆盖

`NetworkInstrumentationCoverage` 描述 Agent 的覆盖范围：
- **EXPLICIT_FACTORY**：App 使用显式的 OkHttpClient Factory 注册，覆盖所有请求
- **INSTRUMENTED_PARTIAL**：只有部分 OkHttpClient 被 Instrument，部分请求可能未捕获

### Export

- **JSON**：完整的 Session + Calls + Summary
- **HAR**：标准 HAR 格式（含 timings）
- **CSV**：表格化导出
- **Raw Bundle**：原始事件数据打包
