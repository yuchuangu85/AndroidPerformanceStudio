# GPU Inspector

## 功能作用

GPU Inspector 是一个 GPU 性能分析工具的集成模块，核心功能包括：

- **Android GPU Inspector (AGI) 集成**：
  - 自动检测本地已安装的 AGI 工具链（`AgiLocator.locate()`）
  - 支持从 AGI 可执行文件路径启动（`launchSupported`）
  - 支持命令行参数传递（System Profile / Frame Profile）
- **GPU 制品管理**：
  - 导入 AGI System Profile、Frame Profile、Perfetto Trace 等 GPU 相关的分析结果文件
  - `AgiArtifactIndexer` 对导入的制品进行 SHA-256 哈希索引，防止重复
  - `JsonAgiArtifactStore` 持久化制品列表到 JSON 文件
- **制品验证**：支持对已导入制品进行哈希完整性验证
- **多方式打开**：根据制品类型选择打开方式：
  - **AGI 打开**：AGI System Profile / Frame Profile
  - **Perfetto 打开**：Perfetto Trace 在应用内 Perfetto Viewer 中打开
  - **桌面打开**：截图、报告等用系统默认程序打开
- **设备上下文记录**：记录 GPU 设备上下文（序列号、型号、API Level、GPU 厂商、渲染器、驱动版本）

## 实现原理

### 工具链集成

1. **AGI 定位**：`AgiLocator` 按以下优先级查找 AGI 可执行文件：
   - 用户手动配置的路径
   - 系统 PATH 环境变量中的 `agi` 或 `gapic`
   - 默认安装路径（Android SDK 目录）
2. **能力检测**：`AgiCapability` 描述 AGI 工具链的能力：
   - `version`：AGI 版本号
   - `launchSupported`：是否支持命令行启动
   - `launchMode`：VERIFIED_CLI / GUI_ONLY / UNSUPPORTED
   - `supportedArguments`：支持的命令行参数
3. **AGI 启动**：`AgiLocator.launch(capability, args)` 启动 AGI 进程并传入制品文件路径

### 制品管理

1. **导入**：用户在 UI 中选择文件，`AgiArtifactIndexer.import()` 分析文件并创建 `GpuArtifact`：
   - 识别制品类型（`GpuArtifactKind`）：AGI_SYSTEM_PROFILE、AGI_FRAME_PROFILE、PERFETTO_TRACE、SCREENSHOT、EXTERNAL_REPORT
   - 计算 SHA-256 哈希
   - 确定打开能力（`ArtifactOpenCapability`）：AGI / PERFETTO / DESKTOP / NONE
2. **去重**：按 SHA-256 去重，避免重复导入相同制品
3. **持久化**：`JsonAgiArtifactStore` 将制品列表以 JSON 格式保存到 `~/.android-performance-studio/gpu-integration/artifacts.json`

### 数据结构

- **GpuArtifact**：GPU 制品，包含 id、kind、path、sha256、sizeBytes、agiVersion、device（GpuDeviceContext）、packageName、graphicsApi、capturedAt、openCapability
- **GpuDeviceContext**：设备上下文，包含 serial、model、apiLevel、gpuVendor、gpuRenderer、driverVersion
- **GpuCaptureContext**：采集上下文，包含 device、packageName、graphicsApi、frameCapture
- **AgiCapability**：AGI 工具链能力，包含 executable、version、launchSupported、launchMode、supportedArguments

### 图形 API 支持

- **Vulkan**：低级图形 API，需要 AGI System Profile
- **OpenGL ES**：传统移动图形 API
- **OpenGL on ANGLE**：通过 ANGLE 转换层运行的 OpenGL

### 数据流

```
[AGI/设备] --导出--> [.gfxtrace / .perfetto-trace] --导入--> [AgiArtifactIndexer]
    --> [GpuArtifact] --> [JsonAgiArtifactStore] (持久化)
    --> [Compose UI: GpuIntegrationScreen]
    --> 打开:
        - AGI System/Frame Profile --> [AgiLocator.launch()] --> [AGI 桌面应用]
        - Perfetto Trace --> [onOpenTrace] --> [Perfetto Viewer]
        - 其他 --> [Desktop.open()] --> [系统默认程序]
```

### 与其他模块的关系

- **Perfetto Viewer**：GPU Inspector 导入的 Perfetto Trace 可委托给 Perfetto Viewer 模块打开（通过 `onOpenTrace` 回调）
- **Source Workspace**：制品导入记录可作为性能证据关联到 Source Workspace
