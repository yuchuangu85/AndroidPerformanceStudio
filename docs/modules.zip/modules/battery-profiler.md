# Battery Profiler

## 功能作用

Battery Profiler 是一个 Android 电池与能耗分析工具，核心功能包括：

- **电池数据采集**：通过 ADB 执行 `dumpsys batterystats` 获取设备电池统计信息
- **多种采集模式**：
  - **Interactive（交互式）**：手动开始/停止，适合在手动操作 App 场景下采集
  - **Timed（定时）**：设定固定时长，自动开始和停止
  - **Repeated（重复）**：多次自动重复采集，用于统计稳定性
  - **Online（在线轮询）**：低频轮询（5-60 秒间隔），实时监控电量变化
- **能耗分析**：`BatteryAnalyzer` 解析 batterystats 数据并计算：
  - **UID 级别**：按 App 聚合资源使用，支持 Package/UID/SharedUID/Device 四种归因范围
  - **Wakelock 分析**：统计各 Wakelock 的持有次数和时长
  - **Alarm 分析**：统计 Alarm 触发次数和类型
  - **Job 分析**：统计 JobScheduler 任务的执行情况
  - **Sensor 分析**：统计传感器使用次数和时长
  - **Network 分析**：统计移动网络/WiFi/蓝牙的收发字节和包数
  - **Energy 估算**：基于硬件计数器或系统模型的能耗估算（mAh 或 µWs）
- **Battery Historian 集成**：支持生成 Battery Historian 兼容的 bugreport，用于深入分析电量事件时间线
- **电池状态采集**：记录设备状态（电量百分比、温度、电压、充电状态）
- **Baseline 对比**：支持配对实验的前后对比
- **结果持久化**：通过 `SqliteBatterySessionStore` 保存实验数据

## 实现原理

### 采集流程

1. **设备选择 → 目标枚举**：通过 ADB 列出可归因 UID 的应用包（`cmd package list packages -U`）
2. **基线采集**：
   - 可选重置全局 batterystats（`dumpsys batterystats --reset`）
   - 采集 baseline 快照（`dumpsys batterystats --checkin` + `dumpsys batterystats`）
3. **实验执行**：
   - 可选自动启动目标 App（`am start`）
   - 根据模式执行采集：Interactive 等待用户停止 / Timed 定时停止 / Repeated 多次循环
4. **最终采集**：获取最终快照 + 历史事件数据
5. **解析**：`BatteryStatsParser` 解析 checkin 格式的 batterystats 数据，提取 UID 级别的资源使用统计

### 数据分析

- `BatteryAnalyzer` 计算 baseline 和 final 之间的差值（Delta）：
  - **Wakelock Delta**：持续时间差值、计数差值
  - **Alarm Delta**：触发次数差值
  - **Network Delta**：收发字节差值
  - **Energy Delta**：能耗估算差值
- 多次运行（Repeated 模式）时的统计分析（min/max/median/mean/P90/P95/stddev/MAD）

### Battery Historian 集成

- `BatteryHistorianAdapter` 通过 ADB 执行 `bugreportz` 生成包含 batterystats history 的 bugreport
- 用户可将生成的 bugreport 导入 Google Battery Historian 进行可视化分析

### 数据结构

- **BatteryExperimentConfig**：实验配置（mode、durationSeconds、pollingIntervalSeconds、measuredRuns、launchApp）
- **BatterySnapshot**：单个采集快照，包含 uidStats、deviceState、history、rawEvidence
- **BatteryRun**：单次实验运行，包含 baseline（基线快照）、samples（中间采样）、finalSnapshot（最终快照）
- **BatteryRunDelta**：计算后的差值数据，包含 wakelocks、alarms、jobs、sensors、network、energy
- **EnergyEstimate**：能耗估算，包含 component、energyMah/energyUws、source（HARDWARE_COUNTER/SYSTEM_MODEL 等）、confidence

### 数据流

```
[Android Device] --ADB--> [dumpsys batterystats] --> [BatteryStatsParser]
    --> [BatterySnapshot[]] --> [BatteryAnalyzer] --> [BatteryRunDelta[]]
    --> [SqliteBatterySessionStore] (持久化)
    --> [Compose UI: BatteryProfilerScreen]

[ADB bugreportz] --> [BatteryHistorianAdapter] --> [bugreport.zip] (for Battery Historian)
```

### Export

- **JSON**：完整分析结果导出
- **CSV**：Delta 数据表格导出
- **Raw Evidence Bundle**：原始 batterystats 数据打包导出

### 注意事项

- batterystats 是全局计数器，需要 reset 或 baseline 对比才能获得单 App 的增量数据
- Energy 估算依赖设备硬件支持，部分设备可能只提供 RESOURCE_BASIC 级别数据
- Battery Historian bugreport 包含隐私敏感信息（账号、SSID、应用列表等）
