# Startup Profiler

## 功能作用

Startup Profiler 是一个 Android 应用启动时间测量与分析工具，核心功能包括：

- **启动时间实验**：通过 ADB 反复启动/停止目标 Activity，精确测量启动耗时
- **启动类型支持**：支持 Cold（冷启动）、Warm（温启动）、Hot（热启动）三种启动类型
- **编译模式覆盖**：支持调整编译模式以模拟不同场景：
  - `CURRENT`：保持当前编译状态
  - `RESET`：重置编译配置（模拟首次安装）
  - `VERIFY`：verify 模式
  - `SPEED_PROFILE`：speed-profile 编译
  - `SPEED`：speed 编译（全量 AOT）
- **实验参数可配**：Warm-up runs（预热次数）、Measured runs（测量次数）、Timeout（超时时间）均可配置
- **统计分析**：`StartupAnalyzer` 对多次测量结果进行统计计算（最小值、最大值、中位数、均值、P90、P95、标准差、MAD）
- **基线对比**：每次实验保留上次结果作为 baseline，支持回归检测
- **结果持久化**：通过 `SqliteStartupSessionStore` 保存实验会话和运行数据到 SQLite 数据库
- **导入/导出**：支持 JSON 格式的导入导出，CSV 格式导出

## 实现原理

### 采集流程

1. **设备选择 → 目标枚举**：通过 ADB `cmd package resolve-activity` 列出可启动的 Activity
2. **Agent 通信**：`SocketStartupAgentConnection` 通过 ADB 端口转发 + Socket 与设备上的 Agent 通信：
   - Agent 控制 App 进程的启动和停止（`am start` / `am force-stop`）
   - Agent 接收 App 内通过 `reportFullyDrawn()` 或首帧绘制完成的信号
3. **实验流程**：
   - 准备阶段：确保设备唤醒、设置编译模式（如需要）
   - Warm-up 阶段：执行配置次数的预热启动（不计入统计）
   - Measured 阶段：执行配置次数的测量启动，每次记录 Displayed Time 或 Fully Drawn Time
4. **超时处理**：每次启动有超时限制（可配 10-120 秒），超时则标记失败

### 数据分析

- `StartupAnalyzer` 对测量的启动时间进行统计：
  - 基础统计：count、min、max、median、mean
  - 百分位数：P90、P95
  - 离散度：standardDeviation、medianAbsoluteDeviation
- 识别异常值（outliers）
- 与 baseline 对比检测回归

### 数据结构

- **StartupRun**：单次运行结果，包含 id、type（COLD/WARM/HOT）、durationMs、compilationMode、startedAt、completedAt
- **StartupSession**：实验会话，包含 deviceSerial、packageName、componentName、config
- **StartupExperimentConfig**：实验配置，包含 requestedType、compilationMode、warmupRuns、measuredRuns、timeoutSeconds
- **StartupAnalysis**：分析结果，包含 runs、statistics、baseline、warnings

### 数据流

```
[Android Device] --ADB Socket--> [Agent] --Start/Stop App--> [StartupExperimentRunner]
    --> [StartupRun[]] --> [StartupAnalyzer] --> [StartupAnalysis]
    --> [SqliteStartupSessionStore] (持久化)
    --> [Compose UI: StartupProfilerScreen]
```

### 启动时间指标

- **Cold Start**：进程从零创建，包含 Application 初始化 + 首 Activity 创建
- **Warm Start**：进程存在但 Activity 被销毁，Activity 重建
- **Hot Start**：进程和 Activity 都在内存中，仅重新 onResume

### Compilation Mode 影响

不同的编译模式影响 ART 编译器的行为：
- **SPEED**：全 AOT 编译，启动最快但安装/OTA 慢
- **SPEED_PROFILE**：基于 Profile 的部分编译，兼顾安装速度和启动速度
- **RESET**：清除编译结果，模拟首次安装后的 JIT 解释执行
