# Benchmark Regression

## 功能作用

Benchmark Regression 是一个 AndroidX Benchmark JSON 结果对比与回归检测工具，核心功能包括：

- **基准数据导入**：导入 AndroidX Benchmark 库生成的 JSON 输出文件
  - Baseline（基线）：作为性能基准的 Benchmark 结果
  - Current（当前）：待对比的最新 Benchmark 结果
- **回归检测**：`RegressionAnalyzer` 对比 Baseline 和 Current 之间的各项指标变化：
  - **绝对差值**（absoluteDelta）
  - **相对变化百分比**（relativeDeltaPercent）
  - **回归分类**：REGRESSED（性能下降）、IMPROVED（性能提升）、STABLE（稳定）、INCONCLUSIVE（不确定）、INCOMPATIBLE（不可比）
- **兼容性检查**：检测 Baseline 和 Current 运行是否可比：
  - 设备信息（model、brand、apiLevel、fingerprint）
  - 构建信息（targetPackage、versionName、versionCode、variant、gitCommit、gitBranch）
  - 不兼容项标记为 `hard`（硬性不兼容）或非 hard（软性差异）
- **可配置的回归策略**：`RegressionPolicy` 支持：
  - `relativeThresholdPercent`：相对变化阈值（如 5%）
  - `absoluteThreshold`：绝对阈值
  - `minimumSampleCount`：最小样本数要求
  - `noiseBandMadMultiplier`：基于 MAD（中位数绝对偏差）的噪声带乘数，排除统计噪声
- **Perfetto Trace 集成**：支持打开 Benchmark 运行中采集的 Perfetto Trace（如果有）
- **报告导出**：支持将回归报告导出为 JSON 格式

## 实现原理

### 解析流程

1. **导入 JSON**：`BenchmarkJsonParser.parse()` 解析 AndroidX Benchmark 的 JSON 输出：
   - 提取设备信息（BenchmarkDevice）：model、brand、apiLevel、osVersion、abi、fingerprint、cpuCoreCount
   - 提取构建信息（BenchmarkBuild）：targetPackage、versionName、versionCode、variant、gitCommit、gitBranch
   - 提取测试 Case 和 Metric：
     - 每个 Case 包含 className、testName、packageName、compilationMode、startupMode
     - 每个 Metric 包含 name、unit、direction（LOWER_IS_BETTER/HIGHER_IS_BETTER）、samples、min/median/max、confidence
2. **持久化**：通过 `SqliteBenchmarkStore` 将解析结果保存到 SQLite

### 对比分析

1. **兼容性检查**：对比设备 fingerprint、构建信息等关键字段，生成 `CompatibilityIssue` 列表
2. **指标匹配**：按 caseIdentity（`className#testName`）+ metricName 匹配 Baseline 和 Current 的对应指标
3. **统计对比**：
   - 取 representative value（median 或中位数）
   - 计算 absoluteDelta = currentValue - baselineValue
   - 计算 relativeDeltaPercent = (delta / baselineValue) * 100
4. **回归判定**：
   - 若 `|relativeDeltaPercent| > thresholdPercent` 且与 Metric 的 direction（期望方向）同向 → REGRESSED
   - 若变化超出噪声带（`noiseBandMadMultiplier * MAD`）→ 有统计显著性
   - 若变化在噪声带内 → STABLE
   - 若样本量不足或置信度不足 → INCONCLUSIVE

### 数据结构

- **BenchmarkRun**：完整的一次 Benchmark 运行，包含 sourceFile、device、build、cases
- **BenchmarkCase**：单个测试 Case，包含 identity（`className#testName`）、metrics、traceArtifacts
- **BenchmarkMetric**：单个指标，包含 name、unit、direction、samples、min/median/max、confidence
- **MetricComparison**：指标对比结果，包含 baselineValue、currentValue、absoluteDelta、relativeDeltaPercent、classification、reasons
- **RegressionReport**：完整的回归报告，包含 comparisons、compatibilityIssues、regressionCount
- **RegressionPolicy**：回归判定策略配置

### 数据流

```
[AndroidX Benchmark JSON] --导入--> [BenchmarkJsonParser] --> [BenchmarkRun]
    --(baseline + current)--> [RegressionAnalyzer] --> [RegressionReport]
    --> [SqliteBenchmarkStore] (持久化)
    --> [Compose UI: BenchmarkRegressionScreen]
    --> [BenchmarkReportExporter] --> [JSON 导出]
```

### Metric Direction

指标的期望方向决定了变化是好是坏：
- **LOWER_IS_BETTER**：值越低越好（如启动时间、帧耗时、内存使用）
- **HIGHER_IS_BETTER**：值越高越好（如帧率、吞吐量）

### 噪声处理

`RegressionPolicy.noiseBandMadMultiplier` 基于 MAD 构建噪声带，防止将正常的测量波动误判为回归：
- 计算 Baseline 样本集的 MAD
- noiseBand = MAD * multiplier（默认 3.0）
- 只有超出 noiseBand 的变化才被视为具有统计显著性的回归

### Output 子模块

- **benchmark-cli**：命令行工具入口（`Main.kt`），可脱离桌面 UI 独立运行回归分析
