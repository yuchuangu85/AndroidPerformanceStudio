# Layout Inspector

## 功能作用

Layout Inspector 是一个 Android 视图层级采集与分析工具，核心功能包括：

- **实时视图层级采集**：通过 ADB 连接设备上的 [Android Agent](shared-kernel/android-agent-view/)，实时获取前台应用或系统 UI 的完整 View 树（包含 View 层级和 Compose Semantics 节点）
- **截图叠加可视化**：采集设备截图并在截图上叠加每个 View 节点的边界框（Bounds），支持点击选中、拖拽平移、缩放等交互
- **层级树浏览**：左侧展示可折叠的 View 层级树，每个节点显示类名、资源 ID，选中后右侧详情面板展示节点属性（ID、类名、文本内容、边界、子节点数、详细属性分组）
- **布局分析规则引擎**：内置静态分析规则，自动检测布局问题：
  - `layout.invisible-node`：不可见但占用空间的节点
  - `layout.excessive-children`：子节点过多（超过阈值）
  - `layout.overlapping-siblings`：兄弟节点重叠比例过高
  - `layout.deep-hierarchy`：层级深度过深
- **AI 布局分析**：可选的 AI 分析集成（`AiAnalysisInputBuilder` + `OpenAiResponsesAnalysisClient`），将布局快照发送给 LLM 进行分析，返回 AI 发现的问题（`AiFinding`），并可关联到源码位置候选
- **时间线对比**：支持采集多帧快照，自动计算帧间 diff（新增/移除/边界变化的节点）
- **离线归档**：支持将布局快照导出/导入为 `CaptureArchive` 格式（含截图、协议数据、分析结果），便于离线分析和分享
- **截图替换**：支持手动导入新截图替换当前截图，用于适配不同分辨率的设备

## 实现原理

### 采集流程

1. **ADB 通道建立**：`LiveDeviceClient` 通过 ADB 建立设备连接，支持 USB 和 TCP/IP 模式
2. **目标选择**：支持两种 `CaptureTargetMode`：
   - `FOREGROUND_APP`：获取前台 Activity 的 View 树
   - `SYSTEM_UI`：获取系统 UI（状态栏、导航栏）的 View 树
3. **Agent 协作**：设备上运行的 Agent 负责：
   - `ViewTreeCollector`：递归遍历 Window 的 View 层级树
   - `ComposeSemanticsCollector`：收集 Compose 的 Semantics 树
   - `LiveSnapshotFactory`：生成包含 View 树 + 截图的快照
4. **协议解码**：`ProtocolCodec` 将 Agent 传回的 JSON 快照解码为 `UiNode` 树结构（区分 `ViewNode` 和 `ComposeNode`）
5. **采集模式**：
   - **自动扫描**（auto-scan）：以固定间隔（`CAPTURE_INTERVAL_MILLIS`）循环采集，自动检测前台切换
   - **手动刷新**：单次触发采集

### 数据结构

- **UiNode**：抽象节点，包含 id、className、bounds、alpha、visibility、children
- **ViewNode**：继承 UiNode，增加 resourceName、viewFlags 等 Android View 特有属性
- **InspectorState**：`InspectorStore` 管理的应用状态，包含 snapshot、selectedNodeId、analysis、timelineFrames

### 数据流

```
[Android Device] --ADB--> [LiveDeviceClient] --Snapshot JSON--> [ProtocolCodec]
    --> [InspectorStore] --State--> [InspectorPresenter] --ScreenModel--> [Compose UI]
                                              |
                                   [Analysis Engine] --findings--> [Findings Panel]
                                   [AI Analysis Client] --aiFindings--> [Findings Panel]
```

### 源码关联

通过 `InspectorCorrelationHint` 与 Source Workspace 建立关联，AI 分析结果中的 `sourceCandidateIds` 可导航到对应的源码位置（`onOpenSourceCandidate`）。
