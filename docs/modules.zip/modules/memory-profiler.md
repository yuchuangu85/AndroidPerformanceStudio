# Memory Profiler

## 功能作用

Memory Profiler 是一个 Android 堆内存分析工具，核心功能包括：

- **Heap Dump 采集**：通过 ADB 在设备上执行 `am dumpheap` 并 pull HPROF 文件，或直接导入已有 HPROF 文件
- **对象图解析**：`HprofParser` 解析 HPROF 二进制格式，提取 Class（类定义）、Instance（对象实例）、ObjectArray（对象数组）、PrimitiveArray（原始类型数组）、GC Root（垃圾回收根）等信息
- **类直方图**：按类聚合统计实例数量、Shallow Size（对象自身大小）、Retained Size（支配树分析后的持有大小），支持多列排序
- **泄漏嫌疑检测**：`DominatorTreeAnalyzer` 基于支配树分析识别潜在内存泄漏对象，提供引用链路径和置信度评估
- **Heap Diff 对比**：`HeapDiffAnalyzer` 对比两次 Heap Dump 之间的类实例数量变化，突出新增、移除和数量变化的类
- **Activity 计数**：统计当前堆中所有 `*Activity` 子类的存活实例数
- **Bitmap Dump**：`BitmapDumpParser` 提取堆中 Bitmap 实例的尺寸和 Retained Size，并通过 `BitmapDumpAnalyzer` 对比两次导出之间的 Bitmap 变化
- **会话持久化**：通过 SQLite（`SqliteMemorySessionStore`）持久化 Heap Dump 和 Bitmap Dump 的元数据，支持会话加载和导出

## 实现原理

### 采集流程

1. **设备选择 → 进程枚举**：通过 ADB `ps` 或 `cmd package` 列出可调试进程
2. **Heap Dump**：通过 ADB 执行 `am dumpheap <pid> <path>`，将 HPROF 写入 `/data/local/tmp/`，再通过 `adb pull` 拉取
3. **HPROF 转换**：Android HPROF 通常需要 `hprof-conv` 将其从 Android 格式转换为标准 Java HPROF 格式
4. **解析**：`HprofParser` 按 HPROF 规范逐 Record 解析：
   - STRING、LOAD CLASS 记录 → 构建字符串和类名映射
   - HEAP DUMP + HEAP DUMP SEGMENT 记录 → 解析实例、数组、类定义、GC Root
   - 构建完整对象图（Object Graph）

### 数据分析

| 分析组件 | 输入 | 输出 | 算法 |
|---------|------|------|-----|
| `MemoryHistogramAnalyzer` | 对象图 | `HeapHistogram`（类统计） | 按 className 聚合 instanceCount + shallowSize |
| `DominatorTreeAnalyzer` | 对象图 | `LeakSuspect` 列表 | 构建支配树、计算 Retained Size，识别异常大的持有者 |
| `HeapDiffAnalyzer` | 前后两次直方图 | `HeapDiff`（变化条目） | 按 className 匹配前后条目，计算 countDelta 和 shallowSizeDelta |
| `BitmapDumpAnalyzer` | 前后两次 Bitmap Dump | `BitmapDumpComparison` | 对比 Bitmap 列表，识别新增/移除/变化的 Bitmap |

### 数据结构

- **HeapDump**：包含 classes、instances、objectArrays、primitiveArrays、gcRoots、leakSuspects、bitmapInstances 等完整对象图
- **HeapHistogram**：按类聚合的统计表，包含 summary（总计）和 classes（ClassStats 列表）
- **HeapDiffEntry**：单类的对比结果，包含前后实例数、Shallow Size 及差值
- **LeakSuspect**：泄漏嫌疑对象，包含 className、reason、retainedSize、referenceChain（引用链路径）、confidence

### 数据流

```
[Android Device] --ADB dumpheap--> [HPROF file] --pull--> [HprofParser]
    --> [HeapDump] --> [MemoryHistogramAnalyzer] --> [HeapHistogram]
    --> [DominatorTreeAnalyzer] --> [LeakSuspect[]]
    --> [HeapDiffAnalyzer] --> [HeapDiff]
    --> [Compose UI: MemoryProfilerScreen]
```

### Export

- **Raw HPROF**：原始或转换后的 HPROF 文件
- **CSV**：类直方图导出
- **Bitmap Dump**：Bitmap 信息打包导出
- **Bitmap Comparison**：Bitamp 对比结果 Markdown 导出
