Synthetic V0.1 demonstration profile. Regenerate with :test-fixtures:generateSampleSession.
